#ERABAKIAK HARTZEKO EUSKARRI SISTEMAREN PROIEKTU FINALA

##Readme honen bidez gure programa exekutatzeko beharrezko pausuak azalduko ditut:

# Text Mining Proiektua

Helburua datu multzo batean datu meatzaritza aplikatzea da.

-Testu gordina csv formatu ulergarrira pasa:

	-String-ak Bow edo idftf.

-Atributu Hautapena

	-AttributeSelection erabilita.

-Sailkapena

	-J48 edo Random Forest sailkapenak
	
	-Parametro ekorketa.

-Ebaluazioa

	-Ebaluazio ez zintzoa, 100 hold-out, 10-fold cross validation.

-Iragarpenak

1.-Iragarpena: Test multzoa emanda, emandako eredu iragarleak egindako iragarpenak gordetzen ditu fitxategi batean.
	
