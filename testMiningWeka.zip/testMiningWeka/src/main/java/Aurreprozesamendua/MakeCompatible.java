package Aurreprozesamendua;

import weka.core.Instances;
import weka.core.Utils;
import weka.core.converters.ArffSaver;
import weka.core.converters.ConverterUtils;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.FixedDictionaryStringToWordVector;
import weka.filters.unsupervised.attribute.Reorder;

import java.io.File;
import java.io.IOException;

public class MakeCompatible {

    /**
     * 4 Parametro behar ditu programak:
     *
     * 	1. raw file-aren testa hold out-ekin sortua
     * 	2. gure train arff-aren errepresentazio bektoriala
     * 	3. atributu zenbakia pasatzeko
     * 	4. train arff-aren errepresentazio bektorialaren testa hold out-ekin sortua
     *
     * @param args the arguments
     * @throws Exception Signals that an exception has occurred
     */

    public static void main(String[] args) throws Exception {
        if(args.length  !=4) {
            System.out.println("Ez duzu arguments atala behar bezala bete!");
            System.out.println("Erabilera:");
            System.out.println("java -jar MakeCompatible.jar devRAW.arff trainBOW.arff hiztegia.txt devBOW.arff");
        } else{

            String devRAWfile = args[0];
            String trainBOWfile = args[1];
            String dictionary = args[2];
            String devBOWfile = args[3];

            // 1.Datuak kargatu: devRaw

            Instances devRAW = datuakKargatu(devRAWfile);
            Instances trainBOW = datuakKargatu(trainBOWfile);

            trainBOW.setClassIndex(trainBOW.numAttributes() - 1);
            devRAW.setClassIndex(0);
            // 2. Atributuak reordenatu, klasea amaieran agertu dadin, horretarako reorder filtroa erabiliko dugu

//            Reorder  reorder = new Reorder();
//            reorder.setAttributeIndices("2-"+devRAW.numAttributes()+",1");
//            reorder.setInputFormat(devRAW);
//            devRAW = Filter.useFilter(devRAW, reorder);


            // 3. Hiztegia kargatu --> Dev-ean sartu egingo dugu FixedDictionaryStringToWordVector

            FixedDictionaryStringToWordVector filterDictionary = new FixedDictionaryStringToWordVector();
            filterDictionary.setDictionaryFile(new File(dictionary));
            filterDictionary.setOutputWordCounts(false);
            filterDictionary.setLowerCaseTokens(true);
            filterDictionary.setInputFormat(devRAW);

            Instances devBOW = Filter.useFilter(devRAW, filterDictionary);
            datuakGorde(devBOWfile, devBOW);
        }

    }


    /**
     * Datuak kargatzeko.
     *
     * @param path daukazun datuen path-a
     * @throws Exception Signals that an exception has occurred
     */


    private static Instances datuakKargatu(String path) throws Exception{
        ConverterUtils.DataSource source = new ConverterUtils.DataSource(path);
        Instances data = source.getDataSet();
        return data;
    }

    /**
     * Datuak gordetzeko.
     *
     * @param path daukazun datuen path-a
     * @param data instantzien datuak
     * @throws Exception Signals that an exception has occurred
     */

    private static void datuakGorde(String path, Instances data) throws Exception {

        Reorder reorder = new Reorder();
        reorder.setAttributeIndices("2-last,1");
        reorder.setInputFormat(data);
        data = Filter.useFilter(data, reorder);

        ArffSaver s = new ArffSaver();
        s.setInstances(data);
        s.setFile(new File(path));
        s.writeBatch();
    }


}
